import { Component, OnInit } from '@angular/core';
import { FoodService } from './services/food.service'
import { Router } from '@angular/router'

import { Platform } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { LoginService } from './services/login.service';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss']
})
export class AppComponent implements OnInit {
  categoryList:any;
  isLogin = false
  restaurant

  page = 'login'
  msg = ''
  reataurantName
  userName
  password
  confirmPassword
  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private _foodSerive: FoodService,
    private _router: Router,
    private _login: LoginService
  ) {
    this.initializeApp();
  }
  ngOnInit(){ 
    if (!JSON.parse(localStorage.getItem('restaurant'))) {
      this.isLogin = false
    }
    else{
      this.isLogin = true
      let localRes = JSON.parse(localStorage.getItem('restaurant'))
      this.restaurant = localRes.restaurantName
      this._router.navigateByUrl('/orders')
      
    }
  }
  initializeApp() {
    this.platform.ready().then(() => {
      this.statusBar.styleDefault();
      this.splashScreen.hide();
    });
  }
  getCategory(){
    this._foodSerive.getCategory().subscribe((res:any)=>{
      this.categoryList = res.data
      // this.categoryList = this.categoryList.reverse()
      this._router.navigate(['/food',  this.categoryList[0]._id ]);

    }, (err) => {
      console.log("err of get cateogry" , err);

    })
  }

  onLogout(){
    this.isLogin = false
    localStorage.removeItem('restaurant')
    this._router.navigateByUrl('/login')
  }

  segmentChanged(ev: any) {
    this.page = ev.target.value
  }

  onSignup(){
    
    if (this.password == this.confirmPassword) {
      let req = {
        name : this.reataurantName,
        username: this.userName,
        password: this.password,
      }
      this.msg = "please wait..."
      this._login.signUp(req).subscribe(
        (res:any)=>{
          console.log(res);          
          if (res.success) {
            this.page = 'login'
            this.reataurantName = ''
            this.userName = ''
            this.password = ''
            this.confirmPassword = ''
            this.msg = ''

            Swal.fire('Your account has been register, Please login')
          }

          else{
            this.msg = "Username already taken, please try different username"
          }
        },(err)=>console.log(err)
      )
    }

    else{
      this.msg = 'password and confirm password didnt matched, please try agaain'
    }
  }

  onLogin(){
    let req = {
      username : this.userName, 
      password : this.password
    }
    this.msg = 'please wait...'
    this._login.login(req).subscribe(
      (res:any)=>{
        if(res.success){
          localStorage.setItem('restaurant', JSON.stringify(res.data));
          this.msg = null
          this.isLogin = true
          this._router.navigateByUrl('/orders')
        }
        else{
          this.msg = 'incorrect username or password'
        }

      },(err)=>console.log(err)
    )
  }
}
