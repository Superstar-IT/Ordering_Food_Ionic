import { Component, OnInit,TemplateRef  } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { SpecialService } from '../services/special.service';
import Swal from 'sweetalert2';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-special',
  templateUrl: './special.component.html',
  styleUrls: ['./special.component.scss'],
})
export class SpecialComponent implements OnInit {
  modalRef: BsModalRef;
  isLoadingSpecial = false
  isSpicy
  filter = []
  items = []
  days = [
    { name : 'Sunday', added: false},
    { name : 'Monday', added: false},
    { name : 'Tuesday', added: false},
    { name : 'Wednesday', added: false},
    { name : 'Thursday', added: false},
    { name : 'Friday', added: false},
    { name : 'Saturday', added: false}
  ]
  constructor(private modalService: BsModalService, private _special:SpecialService,private _route:ActivatedRoute, private _router:Router) { 
    this._route.params.subscribe(val => {
      this.isLoadingSpecial = true
      this._special.getSpecial().subscribe(
        (res:any)=>{
          this.isLoadingSpecial = false
            this.items = res.data
            this.items.forEach((element) => {
              this.days.forEach(dayElement => {
                if (element.day == dayElement.name) {
                  dayElement.added = true
                }
              });
            });
  
            this.items.forEach((element,index) => {
              switch (element.day) {
                case 'Sunday':
                this.filter[0] = element
                break;
              
                case 'Monday':
                this.filter[1] = element
                break;
  
                case 'Tuesday':
                this.filter[2] = element
                break;
  
                case 'Wednesday':
                this.filter[3] = element
                break;
  
                case 'Thursday':
                this.filter[4] = element
                break;
  
                case 'Friday':
                this.filter[5] = element
                break;
  
                case 'Saturday':
                this.filter[6] = element
                break;
  
                default:
                this.filter[index] = null
                  break;
              }
            
            });
        },(err)=>console.log(err)
      )
      
    });
  }
  ngOnInit() {
   
    
  }

  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }

  onDeleteSpecial(index){
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
      if (result.value) {
        this._special.deleteItem(this.filter[index]._id).subscribe(
          (res:any)=>{
            if (res.success) {
              this.filter[index] = null
              this.days[index].added = false
              Swal.fire(
                'Deleted!',
                'Your file has been deleted.',
                'success'
              )
            }
          },(err)=>console.log(err)      
        )
        
      }
    })
  }

  onEditSpecial(index){
    this._special.editSpecial = this.filter[index]
    this._router.navigateByUrl['/special/editItem/:edit']
  }
}
