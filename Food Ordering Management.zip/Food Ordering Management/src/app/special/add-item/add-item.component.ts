import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { SpecialService } from 'src/app/services/special.service';

@Component({
  selector: 'app-add-item',
  templateUrl: './add-item.component.html',
  styleUrls: ['./add-item.component.scss'],
})
export class AddItemSpecialComponent implements OnInit {
  isEdit = false
  imagePreview
  itemName
  itemPrice
  image
  itemDescription
  addItem: FormGroup
  emptyField = false
  day
  isSpicy;
  isCLick= false;
  constructor(private _route:ActivatedRoute, private _special:SpecialService, private _router: Router) { }

  ngOnInit() {    
    this.addItem = new FormGroup({
      image: new FormControl()
    })
    this.isSpicy = false
    this.day = this._route.snapshot.params['day']
    if (this._route.snapshot.params['edit']=='1') {
      this.isEdit = true
      this.itemName = this._special.editSpecial.name
      this.itemPrice = this._special.editSpecial.price
      this.itemDescription = this._special.editSpecial.description
      this.imagePreview = this._special.editSpecial.image
      this.image = this._special.editSpecial.image
      this.day = this._special.editSpecial.day
      this.isSpicy = this._special.editSpecial.isSpicy
    }
    
  }
  onImagePicked(event: Event) {
    const file = (event.target as HTMLInputElement).files[0];
    this.image = file 
    const reader = new FileReader();
    reader.onload = () => {
      this.imagePreview = reader.result;
    }
    reader.readAsDataURL(file);
  }

  crazyEvent(event){
    this.isSpicy = event.detail.checked
  }

  AddItem() {
    this.isCLick = true
    this.emptyField = false
    
    if(this.itemDescription!=null && this.itemName!=null && this.itemPrice!=null && this.imagePreview!=null){
      const itemFormData = new FormData()
      itemFormData.append('name', this.itemName)
      itemFormData.append('image', this.image)
      itemFormData.append('price', this.itemPrice)
      itemFormData.append('description', this.itemDescription)
      itemFormData.append('day', this.day)
      itemFormData.append('isSpicy', this.isSpicy)
      itemFormData.append('restaurant', JSON.parse(localStorage.getItem('restaurant'))._id)

      this._special.addSpecial(itemFormData).subscribe((data:any) => {
        this.itemPrice = ''
        this.itemName = ''
        this.imagePreview = ''
        this.itemDescription = ''
        this._router.navigateByUrl('special')
      })
    }
    else{
      this.isCLick = false
          this.emptyField = true
    }
  }

  updateItem(){
    this.isCLick = true
    const itemFormData = new FormData()
    itemFormData.append('id', this._special.editSpecial._id)
      itemFormData.append('name', this.itemName)
      itemFormData.append('image', this.image)
      itemFormData.append('price', this.itemPrice)
      itemFormData.append('description', this.itemDescription)
      itemFormData.append('day', this.day)
      itemFormData.append('isSpicy', this.isSpicy)
      itemFormData.append('restaurant', JSON.parse(localStorage.getItem('restaurant'))._id)

      this._special.editItem(itemFormData).subscribe(data => {
        this.itemPrice = ''
        this.itemName = ''
        this.imagePreview = ''
        this.itemDescription = ''
        this._router.navigateByUrl('special')
      })
  }

}
