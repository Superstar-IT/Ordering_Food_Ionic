import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { ModalModule } from 'ngx-bootstrap/modal';
import { CommonModule } from "@angular/common";
import { RouteReuseStrategy } from '@angular/router';

import { IonicModule, IonicRouteStrategy } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FoodComponent } from './food/food.component';
import { BaveragesComponent } from './baverages/baverages.component';
import { SpecialComponent } from './special/special.component';
import { OrdersComponent } from './orders/orders.component';
import { HttpClientModule } from '@angular/common/http'
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddItemsComponent } from './add-items/add-items.component';
import { AddItemBaveragesComponent } from './baverages/add-item/add-item.component';
import { AddItemSpecialComponent } from './special/add-item/add-item.component';



@NgModule({
  declarations: [
    AppComponent,
    FoodComponent,
    BaveragesComponent,
    SpecialComponent,
    OrdersComponent,
    AddItemsComponent,
    AddItemBaveragesComponent,
    AddItemSpecialComponent
  ],
  entryComponents: [],
  imports: [
    FormsModule,
    BrowserModule,
    CommonModule,
    ModalModule.forRoot(),
    IonicModule.forRoot(),
    AppRoutingModule,
    ReactiveFormsModule,
    HttpClientModule, 
    FormsModule
  ],
  providers: [
    StatusBar,
    SplashScreen,
    { provide: RouteReuseStrategy, useClass: IonicRouteStrategy }
  ],
  bootstrap: [AppComponent]
})
export class AppModule {}
