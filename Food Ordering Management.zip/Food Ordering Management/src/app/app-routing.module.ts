import { NgModule } from '@angular/core';
import { PreloadAllModules, RouterModule, Routes } from '@angular/router';
import { FoodComponent } from './food/food.component';
import { BaveragesComponent } from './baverages/baverages.component';
import { SpecialComponent } from './special/special.component';
import { OrdersComponent } from './orders/orders.component';
import { AddItemsComponent } from './add-items/add-items.component';
import { AddItemBaveragesComponent } from './baverages/add-item/add-item.component';
import { AddItemSpecialComponent } from './special/add-item/add-item.component';

const routes: Routes = [
  { path: 'addItem/:subCategoryID/:itemID', component: AddItemsComponent},
  { path: 'food', component: FoodComponent},
  { path: 'baverages', component: BaveragesComponent},
  { path: 'special', component: SpecialComponent},
  { path: 'orders', component: OrdersComponent},
  { path: 'baverages/addItem/:subCategoryID', component: AddItemBaveragesComponent},
  { path: 'special/addItem/:day', component: AddItemSpecialComponent},
  { path: 'special/editItem/:edit', component: AddItemSpecialComponent},
  { path: '', redirectTo: 'login', pathMatch: 'full' },
];

@NgModule({
  imports: [
    RouterModule.forRoot(routes, { preloadingStrategy: PreloadAllModules })
  ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
