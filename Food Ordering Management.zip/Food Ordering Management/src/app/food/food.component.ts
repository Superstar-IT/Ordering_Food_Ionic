import { Component, OnInit,TemplateRef, OnChanges  } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ActivatedRoute  , Router} from '@angular/router';
import Swal  from 'sweetalert2'
// import $ from "jquery";

import { FoodService } from './../services/food.service';
declare var $;
@Component({
  selector: 'app-food',
  templateUrl: './food.component.html',
  styleUrls: ['./food.component.scss'],
})
export class FoodComponent implements OnInit,OnChanges {
  isLoadingSubCategories = false
  isLoadingItems = false
  selSubCategory = ''
  modalContent
  subCategories = []
  categoryId = '5f09387ed0bb2521d835ce79'
  subCategoryName
  items = []
  modalRef: BsModalRef;
  isClicked= false
  constructor(
    private modalService: BsModalService,
    private _foodService: FoodService,
    public _route: ActivatedRoute,
    public _router: Router,
  ) { 
    this._route.params.subscribe(val => {
      this.getSubCategory()
    })
  }
  
  ngOnChanges(){
    console.log("change called");
  }

  ngOnInit() {
  }


  openItemsModal(addItemModal: TemplateRef<any>) {
    this.modalRef = this.modalService.show(addItemModal);
  }

  openSubCatModal(modal:TemplateRef<any>){
    this.modalRef = this.modalService.show(modal);
  }


  getSubCategory(){
    this.isLoadingSubCategories = true
    this.isLoadingItems = true
    this._foodService.getSubCategory().subscribe((res:any) => {
      
      if (res.success) {
        if (res.data.length!=0) {
          this.subCategories = res.data
          this.selSubCategory = this.subCategories[0]._id
          this.getItems(this.selSubCategory)
        }
        this.isLoadingSubCategories = false
      }
      this.isLoadingItems = false
    }, (err) => {
      console.log("error in adding category", err);
    });    
  }  
  
  onSelectSubCategory(id){
    this.selSubCategory = id
    this.getItems(id)
  }

  onSubmitSubCategory(){
    this.isClicked = true
    this._foodService.addSubCategory(this.subCategoryName).subscribe((res:any) => {
      this.subCategoryName = ''
      if (res.success) {
        this.subCategories.push(res.data);
        this.selSubCategory = res.data._id
        this.isClicked= false
      }
    }, (err) => {
      console.log("error in adding category", err);
    });
    this.modalRef.hide()
  }


  onDelete(index){        
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
      if (result.value) {
        this._foodService.deleteSubCategory(this.subCategories[index]._id).subscribe(
          (res:any)=>{
            if (res.success) {
              this.subCategories.splice(index,1)
              if (this.subCategories.length!=0) {
                this.selSubCategory = this.subCategories[0]._id
              }
              else{
                this.selSubCategory = ''
              }
              Swal.fire(
                'Deleted!',
                'Your file has been deleted.',
                'success'
              )
            }
          },(err)=>console.log(err)      
        )
        
      }
    })
  }


  getItems(id){
    this.isLoadingItems = false
    this._foodService.getItems(id).subscribe(
      (res:any)=>{
        this.isLoadingItems = false
        if (res.success) {
          
          this.isLoadingItems = false
          this._foodService.items = res.data
          this.items = res.data
        }
      }
      )
      
      this._foodService.itemNotify.subscribe(
        ()=>{
          this.items = this._foodService.items
      }        
    )
  }

  onDeleteItem(index){
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
      if (result.value) {
        this._foodService.deleteItem(this.items[index]._id).subscribe(
          (res:any)=>{
            if (res.success) {
              this._foodService.items.splice(index,1)
              this._foodService.itemNotify.next()
              Swal.fire(
                'Deleted!',
                'Your file has been deleted.',
                'success'
              )
            }
          },(err)=>console.log(err)      
        )
      }
    })
  }
}
