import { Component, OnInit } from '@angular/core';
import { OrdersService } from '../services/orders.service';

@Component({
  selector: 'app-orders',
  templateUrl: './orders.component.html',
  styleUrls: ['./orders.component.scss'],
})
export class OrdersComponent implements OnInit {
  
  isCollapse = []
  orders = []
  wait = false
  constructor(private _order: OrdersService) { }

  ngOnInit() {
   this._order.getOrders().subscribe(
     (res:any)=>{
       if (res.success) {
         this.orders = res.data
         this.orders.forEach(element => {
           element.createdAt = element.createdAt.split("T")[1].split('.')[0];
           this.isCollapse.push(true)
           element.isCollapseOrder = true
          });
       }
     },(err)=>{console.log(err);
     }
   )
  }
  updateOrder(item){
    item.isComplete = true
    this._order.updateOrder(item).subscribe((res)=>{
      this.onRefresh();
    }, (err) => {
      console.log(err);
    });
  }
  onCollapse(index){
    this.orders[index].isCollapseOrder = !this.orders[index].isCollapseOrder
  }

  onRefresh(){
    this.wait = true
    this._order.getOrders().subscribe(
      (res:any)=>{
        if (res.success) {
          this.wait = false
          this.orders = res.data
          this.orders.forEach(element => {
            element.createdAt = element.createdAt.split("T")[1].split('.')[0];
            this.isCollapse.push(true)
            element.isCollapseOrder = true
           });
        }
      },(err)=>{console.log(err);
      }
    )
  }

}
