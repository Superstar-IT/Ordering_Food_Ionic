import { Component, OnInit, TemplateRef } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { FormGroup, FormControl } from '@angular/forms';
import { FoodService } from '../services/food.service';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-add-items',
  templateUrl: './add-items.component.html',
  styleUrls: ['./add-items.component.scss'],
})
export class AddItemsComponent implements OnInit {
  modalRef: BsModalRef;
  addItem: FormGroup
  testForm: FormGroup
  imagePreview
  category = "radio"
  addons = []
  tableAddon = []
  Items: any = []
  editItem: any = []
  isEdit = false
  isClicked= false
  subCategoryID
  itemId
  image
  itemName=null
  itemPrice=null
  itemDescription=null
  emptyField = false
  isSpicy
  constructor(private modalService: BsModalService, private foodService: FoodService, private _router: ActivatedRoute, private _navigate: Router) { }

  ngOnInit() {
    this.isSpicy = false
    this.subCategoryID = this._router.snapshot.params['subCategoryID']
    this.itemId = this._router.snapshot.params['itemID']

    this.addItem = new FormGroup({
      image: new FormControl(),
      name: new FormControl(),
      price: new FormControl(),
      desc: new FormControl()
    })
    this.testForm = new FormGroup({
      test: new FormControl('test')
    })

    this.foodService.getAllItems().subscribe(data => {
      this.Items = data

      for(var i = 0; i < this.Items.data.length; i++){
        if(this.Items.data[i]._id == this.itemId){
          this.isEdit = true
          this.editItem = this.Items.data[i]
          this.itemName = this.editItem.name
          this.itemPrice = this.editItem.price
          this.itemDescription = this.editItem.description
          this.tableAddon = this.editItem.addons
          this.imagePreview = this.editItem.image
          this.isSpicy = this.editItem.isSpicy
          this.subCategoryID = this.editItem.subcategory._id
          this.image = this.editItem.image
        }
      }
    })
  }

  openSubCatModal(modal: TemplateRef<any>) {
    this.modalRef = this.modalService.show(modal);
  }

  onImagePicked(event: Event) {
    const file = (event.target as HTMLInputElement).files[0];
    this.image = file
    const reader = new FileReader();
    reader.onload = () => {
      this.imagePreview = reader.result;
    }
    reader.readAsDataURL(file);
  }

  crazyEvent(event){
    this.isSpicy = event.detail.checked
  }

  AddItem() {
    this.isClicked= true
    this.emptyField = false
    // const itemDetails = {
    //   name: this.itemName,
    //   image: this.addItem.value.image,
    //   price: this.itemPrice,
    //   description: this.itemDescription
    // }
    
    if(this.itemName!=null && this.itemPrice!=null && this.itemDescription!=null){
      const itemFormData = new FormData()
      itemFormData.append('name', this.itemName)
      itemFormData.append('image', this.image)
      itemFormData.append('price', this.itemPrice)
      itemFormData.append('description', this.itemDescription)
      itemFormData.append('subcategory', this.subCategoryID)
      itemFormData.append('isSpicy', this.isSpicy)
      itemFormData.append('restaurant', JSON.parse(localStorage.getItem('restaurant'))._id)
      for(var i = 0; i < this.addons.length; i ++){
        itemFormData.append('addons', JSON.stringify(this.addons[i]))
      }

      this.foodService.addItem(itemFormData).subscribe((data:any) => {
        this.foodService.items.push(data.data)

        this._navigate.navigateByUrl('/food')
        this.foodService.itemNotify.next()
      })
    }
    else{
    this.isClicked= false

      this.emptyField = true
    }
  }

  CategorySelected(value) {
    
    if (value.detail.value == "radio") {
      this.category = "radio"
    } else {
      this.category = "checkbox"
    }
  }

  onSubmitSubCategory(name, option, modal: TemplateRef<any>) {
    const addon = {
      name: name.value,
      options: option.value,
      category: this.category
    }
    this.addons.push(addon)
    this.tableAddon.push(addon)
    this.modalRef.hide()
  }

  onDeleteAddon(index){
    this.tableAddon.splice(index,1)
  }

  UpdateItem(){
    this.emptyField = false

    if(this.itemName!=null && this.itemPrice!=null && this.itemDescription!=null){
      const itemFormData = new FormData()
      itemFormData.append('name', this.itemName)
      itemFormData.append('id', this.itemId)
      itemFormData.append('image', this.image)
      itemFormData.append('price', this.itemPrice)
      itemFormData.append('description', this.itemDescription)
      itemFormData.append('subcategory', this.subCategoryID)
      itemFormData.append('isSpicy', this.isSpicy)
      itemFormData.append('restaurant', JSON.parse(localStorage.getItem('restaurant'))._id)
      for(var i = 0; i < this.tableAddon.length; i ++){
        itemFormData.append('addons', JSON.stringify(this.tableAddon[i]))
      }

      this.foodService.updateItem(itemFormData).subscribe((data:any) => {
        // this.foodService.items.push(data.data)
        
        this.foodService.items.forEach(element => {
          if (element._id == this.itemId) {
            element = data.data
          }
        });
        this._navigate.navigateByUrl('/food')
        this.foodService.itemNotify.next()
      })
    }
    else{
      this.emptyField = true
    }
  }
}
