const baseUrl = "http://localhost:3846/";

// oneplus
// const baseUrl = "http://192.168.43.162:3000/"; 

// zena
// const baseUrl = "http://192.168.0.108:3846/";

// live
// const baseUrl = "http://3.13.6.243:3846/"


export const config = {
    baseApiUrl: baseUrl,
}