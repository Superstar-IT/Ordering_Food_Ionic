import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http'

import { config } from './../config'
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FoodService {
  itemNotify = new Subject<void>()
  items = []

  editItem
  constructor(
  	public _http: HttpClient
  ) { }
  addSubCategory(name){
    let restaurant = JSON.parse(localStorage.getItem('restaurant'))._id;
    let req = {
      name,
      category : '5f09387ed0bb2521d835ce79',
      restaurant
    }

    return this._http.post(config.baseApiUrl+'subcategory/addsubCategory', req)

  }
  getCategory(){
  	return this._http.get(config.baseApiUrl+'category/getCategory')
  }
  getSubCategory(){
    let restaurant = JSON.parse(localStorage.getItem('restaurant'))._id;
      let req = {
        category : '5f09387ed0bb2521d835ce79',
        restaurant
      }  
      return this._http.post(config.baseApiUrl+'subcategory/getsubCategory', req)
  }
  deleteSubCategory(id){
    return this._http.delete(config.baseApiUrl+"subcategory/deletesubCategory/"+id)
  }

  getItems(id){
    let restaurant = JSON.parse(localStorage.getItem('restaurant'))._id;
    let req = {
      id,
      restaurant
    }
    
    return this._http.post(config.baseApiUrl+'item/getItemBySubcategory',req)
  }

  addItem(form){
    // form['restaurant'] = JSON.parse(localStorage.getItem('restaurant'))._id

    return this._http.post(config.baseApiUrl + 'item/addItem', form)
  }

  deleteItem(id){
    return this._http.delete(config.baseApiUrl+"item/deleteItem/"+id)
  }

  updateItem(form){
    return this._http.put(config.baseApiUrl + 'item/updateItem', form)
  }

  getAllItems(){
    let req = {
      restaurant : JSON.parse(localStorage.getItem('restaurant'))._id
    }
    return this._http.post(config.baseApiUrl+'item/getItem',req)
  }
}