import { Injectable } from '@angular/core';
import { config } from '../config';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class SpecialService {
  editSpecial
  constructor(private _http: HttpClient) { }

  addSpecial(form){
    return this._http.post(config.baseApiUrl + 'specials/addSpecials', form)
  }

  getSpecial(){
    let restaurant = JSON.parse(localStorage.getItem('restaurant'))._id;
    let req = {
      restaurant
    }
    return this._http.post(config.baseApiUrl + 'specials/getSpecials',req)
  }

  deleteItem(id){
    return this._http.delete(config.baseApiUrl+"specials/deleteSpecials/"+id)
  }

  editItem(form){
    return this._http.put(config.baseApiUrl + 'specials/updatespecials', form)
  }
}
