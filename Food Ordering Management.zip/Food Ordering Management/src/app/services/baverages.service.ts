import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { config } from '../config';
import { Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class BaveragesService {
  addItemNotify = new Subject<void>()
  allItems = []
  constructor(private _http: HttpClient) { }
  getSubCategories(){
    let restaurant = JSON.parse(localStorage.getItem('restaurant'))._id;
    let req = { 
      category : '5f093896d0bb2521d835ce7a',
      restaurant
    }   
    return this._http.post(config.baseApiUrl+'subcategory/getsubCategory/',req)
  }

  addSubCategory(name){
    let restaurant = JSON.parse(localStorage.getItem('restaurant'))._id;
    let req = {
      name,
      category : '5f093896d0bb2521d835ce7a',
      restaurant
    }
    
    return this._http.post(config.baseApiUrl+'subcategory/addsubCategory', req)

  }

  getItems(id){
    let restaurant = JSON.parse(localStorage.getItem('restaurant'))._id;
    let req = {
      id,
      restaurant
    }
    return this._http.post(config.baseApiUrl+'item/getItemBySubCategory/',req)
  }

  addItem(form){
    return this._http.post(config.baseApiUrl + 'item/addItem', form)
  }

  deleteItem(id){
    return this._http.delete(config.baseApiUrl+"item/deleteItem/"+id)
  }
  
}
