import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { config } from '../config';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private _http: HttpClient) { }

  signUp(req){
    return this._http.post(config.baseApiUrl + "restaurant/restaurantSignup", req)
  }

  login(req){
    return this._http.post(config.baseApiUrl + 'restaurant/restaurantSignin', req)
  }
}
