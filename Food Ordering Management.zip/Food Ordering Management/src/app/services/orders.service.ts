import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { config } from '../config';

@Injectable({
  providedIn: 'root'
})
export class OrdersService {

  constructor(private _http: HttpClient) {
    
   }
   
   getOrders(){
    let restaurant = JSON.parse(localStorage.getItem('restaurant'))._id;
    let req = {
      restaurant
    }
    return this._http.post(config.baseApiUrl+'order/getOrder', req)
   }
   updateOrder(item){
     item['id'] = item._id;
    let restaurant = JSON.parse(localStorage.getItem('restaurant'))._id;
    item['restaurant'] = restaurant
    // let restaurant = JSON.parse(localStorage.getItem('restaurant'))._id;
    // let req = {
    //   restaurant
    // }
    return this._http.put(config.baseApiUrl+'order/updateOrder', item)
   }
}
