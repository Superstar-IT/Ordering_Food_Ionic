import { TestBed } from '@angular/core/testing';

import { BaveragesService } from './baverages.service';

describe('BaveragesService', () => {
  let service: BaveragesService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BaveragesService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
