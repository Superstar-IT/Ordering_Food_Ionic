import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { IonicModule } from '@ionic/angular';

import { BaveragesComponent } from './baverages.component';

describe('BaveragesComponent', () => {
  let component: BaveragesComponent;
  let fixture: ComponentFixture<BaveragesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BaveragesComponent ],
      imports: [IonicModule.forRoot()]
    }).compileComponents();

    fixture = TestBed.createComponent(BaveragesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  }));

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
