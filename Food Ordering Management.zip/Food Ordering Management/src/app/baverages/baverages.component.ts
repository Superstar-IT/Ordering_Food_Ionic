import { Component, OnInit, TemplateRef } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { BaveragesService } from '../services/baverages.service';
import { FoodService } from '../services/food.service';
import Swal from 'sweetalert2';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-baverages',
  templateUrl: './baverages.component.html',
  styleUrls: ['./baverages.component.scss'],
})
export class BaveragesComponent implements OnInit {
  subCategories = []
  items = []
  temp = ['teasdasd']
  modalRef: BsModalRef;
  selItems = 0
  selSubCategory: any;
  subCategoryName: any;

  categoryId = '5f093896d0bb2521d835ce7a'
  constructor(private _route: ActivatedRoute,private modalService: BsModalService, private _baverages: BaveragesService, private _foodService : FoodService) {
    this._route.params.subscribe(val => {
      this.getSubCategory()
    })
   }

  ngOnInit() {
    this.getSubCategory()
  }
  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }
  openSubCatModal(modal:TemplateRef<any>){
    this.modalRef = this.modalService.show(modal);
  }
  getSubCategory(){
    this._baverages.getSubCategories().subscribe((res:any) => {
      if (res.data.length!=0) {
        this.subCategories = res.data
        this.selSubCategory = this.subCategories[0]._id
        this.getItems(this.selSubCategory)
      }
    }, (err) => {
      console.log("error in adding category", err);
    });    
  }  
  onSubmitSubCategory(){

    let name = this.subCategoryName
    this.subCategoryName = ''
    this._baverages.addSubCategory(name).subscribe((res:any) => {
      if (res.success) {
        this.modalRef.hide()
        this.subCategories.push(res.data);
      }
    }, (err) => {
      console.log("error in adding category", err);
    });
  }

  onSelectSubCategory(id,index){
    this.selSubCategory = id
    // this.selItems = index
    this.getItems(id)
  }

  getItems(id){
    this._foodService.getItems(id).subscribe(
      (res:any)=>{
        console.log(res);
        
        if (res.success) {
          
          this._foodService.items = res.data
          this.items = res.data
        }
      }
      )
  }

  onDelete(itemIndex){
   
    
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
      if (result.value) {
        this._baverages.deleteItem(this.items[itemIndex]._id).subscribe(
          (res:any)=>{
            if (res.success) {
              this.items.splice(itemIndex,1)
              Swal.fire(
                'Deleted!',
                'Your file has been deleted.',
                'success'
              )
            }
          },(err)=>console.log(err)      
        )
        
      }
    })
  }

  onDeleteSubCategory(index){        
    Swal.fire({
      title: 'Are you sure?',
      text: "You won't be able to revert this!",
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#3085d6',
      cancelButtonColor: '#d33',
      confirmButtonText: 'Yes, delete it!'
    }).then((result) => {
      if (result.value) {
        this._foodService.deleteSubCategory(this.subCategories[index]._id).subscribe(
          (res:any)=>{
            if (res.success) {
              this.subCategories.splice(index,1)
              if (this.subCategories[0]) {
                if (this.subCategories.length!=0) {
                  this.selSubCategory = this.subCategories[0]._id
                  this.getItems(this.selSubCategory)
                }
                else{
                  this.selSubCategory = ''
                }
              }
              Swal.fire(
                'Deleted!',
                'Your file has been deleted.',
                'success'
              )
            }
          },(err)=>console.log(err)      
        )
        
      }
    })
  }

}
