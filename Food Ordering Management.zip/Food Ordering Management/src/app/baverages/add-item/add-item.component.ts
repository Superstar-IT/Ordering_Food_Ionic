import { Component, OnInit, Output } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { BaveragesService } from 'src/app/services/baverages.service';
import { FoodService } from 'src/app/services/food.service';

@Component({
  selector: 'app-add-item',
  templateUrl: './add-item.component.html',
  styleUrls: ['./add-item.component.scss'],
})
export class AddItemBaveragesComponent implements OnInit {
  imagePreview
  isEdit = false
  itemName
  itemPrice
  addItem: FormGroup
  emptyField = false
  subCategoryID
  Items
  image
  editItemId
  editItem: any = []
  constructor(private _router: Router, private _route:ActivatedRoute, private _baverages: BaveragesService, private foodService: FoodService) { }

  ngOnInit() {
    this.addItem = new FormGroup({
      image: new FormControl()
    })
    this.subCategoryID = this._route.snapshot.params['subCategoryID']
    this.editItemId = this._route.snapshot.params['subCategoryID']

    this.foodService.getAllItems().subscribe(data => {
      this.Items = data
      for(var i = 0; i < this.Items.data.length; i++){
        if(this.Items.data[i]._id == this.editItemId){
          this.isEdit = true
          this.editItem = this.Items.data[i]
          this.itemName = this.editItem.name
          this.image = this.editItem.image
          this.itemPrice = this.editItem.price
          this.imagePreview = this.editItem.image
          this.subCategoryID = this.editItem.subcategory._id
        }
      }
    })
  }

  onImagePicked(event: Event) {
    const file = (event.target as HTMLInputElement).files[0];
    this.image = file 
    const reader = new FileReader();
    reader.onload = () => {
      this.imagePreview = reader.result;
    }
    reader.readAsDataURL(file);
  }

  AddItem() {
    this.emptyField = false
    if(this.itemName!=null && this.itemPrice!=null && this.imagePreview!=null){
      const itemFormData = new FormData()
      itemFormData.append('name', this.itemName)
      itemFormData.append('image',  this.image)
      itemFormData.append('price', this.itemPrice)
      itemFormData.append('subcategory', this.subCategoryID)
      itemFormData.append('restaurant', JSON.parse(localStorage.getItem('restaurant'))._id)

      this._baverages.addItem(itemFormData).subscribe((data:any) => {
        this.itemPrice = ''
        this.itemName = ''
        this.imagePreview = ''
        this._router.navigateByUrl('baverages')
      })
    }
    else{
      this.emptyField = true
    }
  }

  UpdateItem(){
    const itemFormData = new FormData()
    itemFormData.append('id', this.editItemId)
      itemFormData.append('name', this.itemName)
      itemFormData.append('image', this.image)
      itemFormData.append('price', this.itemPrice)
      itemFormData.append('subcategory', this.subCategoryID)
      itemFormData.append('restaurant', JSON.parse(localStorage.getItem('restaurant'))._id)

      this.foodService.updateItem(itemFormData).subscribe(data => {
        this.isEdit = false
        this._router.navigateByUrl('baverages')
        this.foodService.itemNotify.next()
      })
  }
}
